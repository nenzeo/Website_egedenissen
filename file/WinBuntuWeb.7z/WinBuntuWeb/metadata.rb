name 'WinBuntuWeb'
maintainer 'Stig Ragnar Røsnes'
maintainer_email 'stig@egedenissen.no'
license 'All Rights Reserved'
description 'Installs/Configures a Web server on Windows and Ubuntu'
long_description 'Installs and configures a web server on both Windows server and Ubuntu Server'
version '0.1.0'
chef_version '>= 12.14' if respond_to?(:chef_version)